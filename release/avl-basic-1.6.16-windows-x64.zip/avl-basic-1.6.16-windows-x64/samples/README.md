# AVL BASIC sample gallery

AVL BASIC ships with **143 runnable programs**. They are not filler or API
snippets: the collection includes complete visual pieces, playable programs,
numerical algorithms, interactive explorers, and focused teaching examples.

The 20 visual highlights below are followed by the complete
143-program catalog. On GitHub, select any image or program name
to inspect its BASIC source.

## Start here

<a id="highlight-g-dustline"></a>
<p align="center">
  <a href="g-dustline.bas"><img src="showcase/g-dustline.png" alt="Dustline running in AVL BASIC" width="820"></a>
</p>
<p align="center">
  <strong>1. Dustline</strong><br>
  Race a banked dirt circuit with controllable drifts, persistent pixel mud, ramp jumps, a session-best ghost, and colored sector times.<br>
  <sub><strong>Shows:</strong> DEF SUB · multiline DEF FN · LOCAL · array references · block IF · procedure error handling · BLOAD · TRECTANGLE · ALPHA · fixed-step physics · KEYDOWN · AUDIO · sequential files · spatial indexing</sub><br>
  <code>RUN "/samples/g-dustline.bas"</code>
</p>

<table>
<tr>
<td width="50%" valign="top">
  <a id="highlight-g-raytracer"></a>
  <a href="g-raytracer.bas"><img src="showcase/g-raytracer.png" alt="Ray Tracer running in AVL BASIC" width="100%"></a><br>
  <strong>2. Ray Tracer</strong><br>
  A 640×480 glass-and-mirrors scene ray-traced entirely in BASIC.<br>
  <sub><strong>Shows:</strong> ray tracing · Fresnel · reflection and refraction</sub><br>
  <code>RUN "/samples/g-raytracer.bas"</code>
</td>
<td width="50%" valign="top">
  <a id="highlight-g-arkanoid"></a>
  <a href="g-arkanoid.bas"><img src="showcase/g-arkanoid.png" alt="AVL Arkanoid running in AVL BASIC" width="100%"></a><br>
  <strong>3. AVL Arkanoid</strong><br>
  A playable brick-breaker with stereo sound effects and sprite/color collisions.<br>
  <sub><strong>Shows:</strong> sprite collisions · color collisions · mouse input · AUDIO · WAV</sub><br>
  <code>RUN "/samples/g-arkanoid.bas"</code>
</td>
</tr>
<tr>
<td width="50%" valign="top">
  <a id="highlight-g-bigbang"></a>
  <a href="g-bigbang.bas"><img src="showcase/g-bigbang.png" alt="Big Bang running in AVL BASIC" width="100%"></a><br>
  <strong>4. Big Bang</strong><br>
  Thousands of pixels explode into particles and reassemble as a second image.<br>
  <sub><strong>Shows:</strong> BLOAD · TEST · particle morphing</sub><br>
  <code>RUN "/samples/g-bigbang.bas"</code>
</td>
<td width="50%" valign="top">
  <a id="highlight-g-zoomer"></a>
  <a href="g-zoomer.bas"><img src="showcase/g-zoomer.png" alt="BASIC Zoomer running in AVL BASIC" width="100%"></a><br>
  <strong>5. BASIC Zoomer</strong><br>
  Block-sampled texture mapping powers a retro zoomer.<br>
  <sub><strong>Shows:</strong> BLOAD · TEST · block rendering</sub><br>
  <code>RUN "/samples/g-zoomer.bas"</code>
</td>
</tr>
<tr>
<td width="50%" valign="top">
  <a id="highlight-g-dungeon"></a>
  <a href="g-dungeon.bas"><img src="showcase/g-dungeon.png" alt="AVL Dungeon running in AVL BASIC" width="100%"></a><br>
  <strong>6. AVL Dungeon</strong><br>
  Explore a textured maze with warm torch lighting and a lantern with transparent glass, find the gold key and escape through the locked gate, with original music and sound effects.<br>
  <sub><strong>Shows:</strong> DEF SUB · DEF FN · LOCAL · array references · block IF · DDA raycasting · TRECTANGLE · TQUAD · perspective correction · vertex lighting · light map · depth testing · ALPHA · AUDIO · WAV</sub><br>
  <code>RUN "/samples/g-dungeon.bas"</code>
</td>
<td width="50%" valign="top">
  <a id="highlight-g-animation2"></a>
  <a href="g-animation2.bas"><img src="showcase/g-animation2.png" alt="Real-Time Moving Light running in AVL BASIC" width="100%"></a><br>
  <strong>7. Real-Time Moving Light</strong><br>
  A rotating light shades a mathematical surface while the camera stays fixed; SPACE pauses motion and C toggles the 60 FPS cap.<br>
  <sub><strong>Shows:</strong> GTRIANGLE · procedural mesh · moving light · vertex lighting · FRAME</sub><br>
  <code>RUN "/samples/g-animation2.bas"</code>
</td>
</tr>
<tr>
<td width="50%" valign="top">
  <a id="highlight-g-voxel"></a>
  <a href="g-voxel.bas"><img src="showcase/g-voxel.png" alt="Voxel World running in AVL BASIC" width="100%"></a><br>
  <strong>8. Voxel World</strong><br>
  Fly over a procedural landscape with filtered lighting, cached fog colors and adjustable viewing distance.<br>
  <sub><strong>Shows:</strong> voxel terrain · procedural generation · lighting · fog · FRAME</sub><br>
  <code>RUN "/samples/g-voxel.bas"</code>
</td>
<td width="50%" valign="top">
  <a id="highlight-g-smoke"></a>
  <a href="g-smoke.bas"><img src="showcase/g-smoke.png" alt="Smoke Simulation running in AVL BASIC" width="100%"></a><br>
  <strong>9. Smoke Simulation</strong><br>
  Interactive two-dimensional fluid simulation with pressure projection, vorticity and smoothly shaded dye.<br>
  <sub><strong>Shows:</strong> fluid simulation · MAT · bilinear interpolation · FRAME</sub><br>
  <code>RUN "/samples/g-smoke.bas"</code>
</td>
</tr>
<tr>
<td width="50%" valign="top">
  <a id="highlight-g-fmandelbrot"></a>
  <a href="g-fmandelbrot.bas"><img src="showcase/g-fmandelbrot.png" alt="Mandelbrot Explorer running in AVL BASIC" width="100%"></a><br>
  <strong>10. Mandelbrot Explorer</strong><br>
  Click into the Mandelbrot set and dive deeper with every redraw.<br>
  <sub><strong>Shows:</strong> complex iteration · mouse zoom · SCALE</sub><br>
  <code>RUN "/samples/g-fmandelbrot.bas"</code>
</td>
<td width="50%" valign="top">
  <a id="highlight-g-chess960"></a>
  <a href="g-chess960.bas"><img src="showcase/g-chess960.png" alt="Chess960 Generator running in AVL BASIC" width="100%"></a><br>
  <strong>11. Chess960 Generator</strong><br>
  Generate legal Chess960 back ranks, rendered with real pieces and one-key rerolls.<br>
  <sub><strong>Shows:</strong> DEF SUB · constrained randomization · sprites</sub><br>
  <code>RUN "/samples/g-chess960.bas"</code>
</td>
</tr>
<tr>
<td width="50%" valign="top">
  <a id="highlight-g-maze"></a>
  <a href="g-maze.bas"><img src="showcase/g-maze.png" alt="Maze Generator running in AVL BASIC" width="100%"></a><br>
  <strong>12. Maze Generator</strong><br>
  A fresh maze appears with its solution stitched through it in a dashed path.<br>
  <sub><strong>Shows:</strong> DFS/Prim · bit masks · path reconstruction</sub><br>
  <code>RUN "/samples/g-maze.bas"</code>
</td>
<td width="50%" valign="top">
  <a id="highlight-g-jelly"></a>
  <a href="g-jelly.bas"><img src="showcase/g-jelly.png" alt="Jelly running in AVL BASIC" width="100%"></a><br>
  <strong>13. Jelly</strong><br>
  Ten thousand points fold into a living neon form.<br>
  <sub><strong>Shows:</strong> parametric plotting · offscreen rendering · FRAME</sub><br>
  <code>RUN "/samples/g-jelly.bas"</code>
</td>
</tr>
<tr>
<td width="50%" valign="top">
  <a id="highlight-g-balls"></a>
  <a href="g-balls.bas"><img src="showcase/g-balls.png" alt="Colliding Balls running in AVL BASIC" width="100%"></a><br>
  <strong>14. Colliding Balls</strong><br>
  Fifty numbered sprites bounce and collide without full clears.<br>
  <sub><strong>Shows:</strong> sprite collisions · dirty redraw · COLMODE</sub><br>
  <code>RUN "/samples/g-balls.bas"</code>
</td>
<td width="50%" valign="top">
  <a id="highlight-g-ftree4"></a>
  <a href="g-ftree4.bas"><img src="showcase/g-ftree4.png" alt="Animated Tree running in AVL BASIC" width="100%"></a><br>
  <strong>15. Animated Tree</strong><br>
  Animated swaying tree redraws recursive branches each frame.<br>
  <sub><strong>Shows:</strong> simulated recursion · EVERY · offscreen rendering</sub><br>
  <code>RUN "/samples/g-ftree4.bas"</code>
</td>
</tr>
<tr>
<td width="50%" valign="top">
  <a id="highlight-g-old-school"></a>
  <a href="g-old-school.bas"><img src="showcase/g-old-school.png" alt="Old-School Demo running in AVL BASIC" width="100%"></a><br>
  <strong>16. Old-School Demo</strong><br>
  A demoscene postcard with a starfield, copper bars, sine scroller and original looping music.<br>
  <sub><strong>Shows:</strong> 3D starfield · SPRITE$ · sine scroller · AUDIO · WAV</sub><br>
  <code>RUN "/samples/g-old-school.bas"</code>
</td>
<td width="50%" valign="top">
  <a id="highlight-g-bifurcation"></a>
  <a href="g-bifurcation.bas"><img src="showcase/g-bifurcation.png" alt="Bifurcation Explorer running in AVL BASIC" width="100%"></a><br>
  <strong>17. Bifurcation Explorer</strong><br>
  Explore chaos by clicking into a rainbow logistic-map bifurcation diagram.<br>
  <sub><strong>Shows:</strong> logistic map · Lyapunov exponent · mouse zoom</sub><br>
  <code>RUN "/samples/g-bifurcation.bas"</code>
</td>
</tr>
<tr>
<td width="50%" valign="top">
  <a id="highlight-g-knot-light"></a>
  <a href="g-knot-light.bas"><img src="showcase/g-knot-light.png" alt="Procedural Knot Light running in AVL BASIC" width="100%"></a><br>
  <strong>18. Procedural Knot Light</strong><br>
  A nearby mouse-controlled diffuse light shades a smooth tubular knot; SPACE pauses rotation while the light remains active, and C toggles the 60 FPS cap, with measured FPS in the HUD.<br>
  <sub><strong>Shows:</strong> parametric mesh · smooth normals · MOUSE · GTRIANGLE · depth buffer</sub><br>
  <code>RUN "/samples/g-knot-light.bas"</code>
</td>
<td width="50%" valign="top">
  <a id="highlight-g-shadow-adaptive"></a>
  <a href="g-shadow-adaptive.bas"><img src="showcase/g-shadow-adaptive.png" alt="Arch Shadows running in AVL BASIC" width="100%"></a><br>
  <strong>19. Arch Shadows</strong><br>
  Move the light with the mouse and watch the arch cast shadows across the floor.<br>
  <sub><strong>Shows:</strong> GTRIANGLE · cast shadows · shared calculations · conservative bounds · adaptive floor mesh</sub><br>
  <code>RUN "/samples/g-shadow-adaptive.bas"</code>
</td>
</tr>
<tr>
<td width="50%" valign="top">
  <a id="highlight-g-cloth"></a>
  <a href="g-cloth.bas"><img src="showcase/g-cloth.png" alt="Cloth running in AVL BASIC" width="100%"></a><br>
  <strong>20. Cloth</strong><br>
  Watch satin cloth fall and drape over a sphere in real time; SPACE pauses, R restarts the fall, and mouse dragging pulls the fabric while it runs.<br>
  <sub><strong>Shows:</strong> DEF SUB · DEF FN · LOCAL · array references · block IF · MAT · XPBD · GTRIANGLE · fixed-step physics · state interpolation · MOUSE · FRAME</sub><br>
  <code>RUN "/samples/g-cloth.bas"</code>
</td>
<td width="50%"></td>
</tr>
</table>

Every image above was captured from the real Rust runtime.

## Suggested learning routes

- **From wireframes to perspective texture mapping:** `g-cube2.bas` → `g-cube-tquad.bas`; DATA defines the eight vertices and six face connections, and one native TQUAD per face supplies inverse depth for perspective correction and depth testing.
- **Interpolate colors and hide faces with depth:** `g-cube.bas` → `g-cube-gouraud.bas`.
- **Move a diffuse light with the mouse:** `g-cube-gouraud.bas` → `g-cube-light.bas`.
- **Combine perspective textures, lighting, and shared depth:** `g-cube-tquad.bas` + `g-cube-light.bas` → `g-cube-textured-light.bas`; a paused cube and nearby point light expose four vertex brightness values. Move the mouse; F compares nearby/broad light, V toggles vertex markers, SPACE resumes rotation, 1/2 compare texture and lighting, T switches quads/triangles, G toggles the Gouraud fin, M animates the light, C toggles the frame-rate cap, and ESC exits. The four light samples are interpolated across two triangles; a small spot within a face needs explicit subdivision or per-pixel lighting.
- **Cut holes in 2D textured shapes:** `g-texture-transparent.bas`; compare opaque and transparent rows over a checkerboard. Four columns show TRECTANGLE with automatic UVs, TRECTANGLE with repeating UVs, TTRIANGLE, and TQUAD. Adding final color 6 (magenta) opens the grille holes, just as in SPRITE; ESC exits.
- **Fade a flying fairy over a picture:** `g-sprite-alpha.bas` combines `SPRITE MOVE ... ALPHA` with the existing anime background and a large, multicolored anime fairy; the area outside the character remains transparent while its colors fade between 0% and 100%.
- **Give parts of a sprite different opacity:** `g-sprite-alpha.bas` → `g-sprite-layers.bas`; capture the body and wings from a two-frame sheet, move both sprites together, and draw the 50%-opaque wings before the fully opaque body. Change WINGALPHA to adjust only the wings.
- **See through a rotating textured cube:** `g-texture-transparent.bas` → `g-cube-transparent.bas`; six perspective-correct grille faces share depth with a four-corner Gouraud background, so each hole reveals the farther faces or the interpolated background colors.
- **Explore light on curves and overlapping surfaces:** `g-cube-light.bas` → `g-knot-light.bas`.
- **Light a first-person scene with textured quads:** `g-cube-textured-light.bas` → `g-dungeon.bas` / `g-dungeon-cpc.bas`; one texture per plane and a fixed world mesh keep the precalculated torch lighting anchored to the floor and ceiling while the camera moves. Near-plane clipping preserves each tile's original triangles and interpolated light. The foreground lantern keeps its brass opaque and uses ALPHA for glass and flame glow. Q changes wall resolution.
- **Cast shadows from a movable light:** `g-cube-light.bas` → `g-shadow.bas`.
- **Optimize a shadow demo with shared calculations and adaptive detail:** `g-shadow.bas` → `g-shadow-adaptive.bas`.
- **Animate the camera, then move the light:** `g-animation.bas` → `g-animation2.bas`.
- **Watch and interact with falling cloth:** `g-cloth.bas`; pause the simulation, restart the fall, or pull the fabric with the mouse.
- **Use array arithmetic in a simulation:** `g-cloth.bas` uses `MAT` for particle velocities and light-space coordinates. Its default 128×128 shadow map and 3×3 filter preserve the original penumbra width; set `ShadowSize=256` and `ShadowPcf=5` to restore the original shadow quality. Physical resolution and solver passes stay unchanged.
- **Organize larger BASIC programs:** `g-cloth.bas`, `g-dungeon.bas` and `g-dungeon-cpc.bas` use named procedures and functions, local variables, array reference parameters, mixed-case names and indented blocks. Short conditions stay inline and closely related statements can share a line with colons. Cloth keeps its solver operations together to avoid extra calls per particle; a few forward skips to loop ends preserve fast rejection in its hottest solver loops, since AVL BASIC has no `CONTINUE FOR`. Its lighting calculation remains a subroutine, while a function validates checkpoint headers. The CPC dungeon retains top-level audio handlers and interrupt-control bridges: `ON SQ`, `DI` and `EI` have procedure restrictions, and a queue callback can interrupt a function, where `CALL` is forbidden. Those handlers keep their legacy `GOSUB`/`RETURN` form.
- **Build a texture mapper, then use the native primitive:** `g-zoomer.bas` →
  `g-zoomer-tquad.bas`.
- **From flat to interpolated light:** `g-lambert.bas` → `g-gouraud.bas`.
- **Build a demoscene effect:** `g-starfield.bas` + `g-sine-scroll.bas` →
  `g-old-school.bas`.
- **Compare two tunnel engines:** `g-tunnel.bas` → `g-tunnel-tquad.bas`; two boundary rings and 48 native perspective-correct TQUAD walls replace depth subdivisions. Angular segments still describe the cylindrical geometry.
- **Learn collisions, then build a game:** `g-balls.bas` + `g-sprite5.bas` →
  `g-arkanoid.bas`.
- **Drive a scrolling time trial:** [`g-dustline.bas`](g-dustline.bas) combines controllable drifts, banked corners, spectators, persistent pixel mud, a session-best ghost and a saved lap record; [see the running sample](showcase/g-dustline.png). Mud is thrown only while sliding and covers track arrows, wooden planks and kerbs. Run `RUN "/samples/g-dustline.bas"`. Use arrows or WASD to drive, SPACE for the handbrake, P to pause, R to restart, G to show or hide the ghost, M to mute, and ESC to exit. The ghost appears after the first valid lap and is replaced when you improve the session best, accompanied by a brighter lap sound. Colored splits compare each sector with its best time from completed valid session laps; the minimap highlights the latest completed sector until the next split or the finish. Restarting preserves session records and the ghost, and recording continues while the ghost is hidden. Invalid laps and demo laps cannot improve session records. At the title screen, ENTER starts and D runs the demo.
  Repeated passes reshape and recolor the existing mud clods. Untouched patches stay fully visible for 30 seconds of driving, then gradually fade over another 60-90 seconds, so old trails clear without a sudden reset at the finish. Pausing also pauses soil aging. The split display and minimap share vivid green and red highlights.
  The softer tyre-on-dirt sound is audible only while the rear tyres slide fast enough to leave mud marks; it fades out when grip returns or the car becomes airborne.
  Five automatic audio-only gears let the engine pitch rise and fall at shifts, with separate upshift and downshift speeds to prevent hunting. They shape the sound independently of the car physics.
  Curb impacts and hard landings share a short, low thump.
  The prerendered surroundings use faceted lighting and fixed grass color patterns with a limited palette on a two-pixel grid; the dirt track retains its finer granular material. Scenery silhouettes clear the projected track and raised kerbs; directional shadows follow the terrain and remain attached to their objects. The complete finish is baked into the background, adding no drawing work per frame.
  The source also demonstrates modern BASIC: 51 named procedures, multiline functions, local variables, whole-array reference parameters for initialization and sector records, indentation and apostrophe comments. Compound variable names use mixed case, such as `CarScale`. Block IF statements organize longer branches; short conditions remain inline, with or without ELSE, and closely related statements can share a line with colons. Record loading and saving handle their own file errors with procedure-local `ON ERROR` and `RESUME`; the main program retains a global handler for unexpected errors. This organization preserves the approved driving, mud and scenery.
- **Modernize a classic algorithm:** `pimachin.bas` → `pimachin-modern.bas`.
- **Save and recover data:** `f-scores.bas` → `f-text.bas` → `f-records.bas`.

## Full catalog — 143 programs

The catalog separates polished pieces from small, purposeful probes. That
makes the latter easier to find without pretending every test is a headline
demo.

### Showcase animations and retro effects (18)

| Sample | What it demonstrates | Techniques |
|---|---|---|
| <a id="sample-g-bernoulli"></a>[`g-bernoulli.bas`](g-bernoulli.bas) | Animated five-lobed radial point curve. | PLOT, ORIGIN, FRAME |
| <a id="sample-g-bernoulli2"></a>[`g-bernoulli2.bas`](g-bernoulli2.bas) | Time-varying radial lobes with cycling colors. | PLOT, trigonometry, FRAME |
| <a id="sample-g-bigbang"></a>[`g-bigbang.bas`](g-bigbang.bas) [★](#highlight-g-bigbang) | Thousands of pixels explode into particles and reassemble as a second image. | BLOAD, TEST, particle morphing |
| <a id="sample-g-bobs"></a>[`g-bobs.bas`](g-bobs.bas) | Six depth-sorted circles orbit in simulated 3D. | 3D projection, depth sorting, FCIRCLE |
| <a id="sample-g-cooperative"></a>[`g-cooperative.bas`](g-cooperative.bas) | Two animations redraw sequentially on each timer pulse. | EVERY, ORIGIN, sequential redraw |
| <a id="sample-g-dot-tunnel"></a>[`g-dot-tunnel.bas`](g-dot-tunnel.bas) | Twisting 3D dot tunnel with star backdrop. | 3D projection, procedural animation, FRAME |
| <a id="sample-g-jelly"></a>[`g-jelly.bas`](g-jelly.bas) [★](#highlight-g-jelly) | Ten thousand points fold into a living neon form. | parametric plotting, offscreen rendering, FRAME |
| <a id="sample-g-old-school"></a>[`g-old-school.bas`](g-old-school.bas) [★](#highlight-g-old-school) | A demoscene postcard with a starfield, copper bars, sine scroller and original looping music. | 3D starfield, SPRITE$, sine scroller, AUDIO, WAV |
| <a id="sample-g-roulette"></a>[`g-roulette.bas`](g-roulette.bas) | Rotating colored circle sectors create a pinwheel. | FCIRCLE, animation, DEG |
| <a id="sample-g-scroll"></a>[`g-scroll.bas`](g-scroll.bas) | Diagonal rotating-text scroll with offscreen redraw. | LDIR, LABEL, offscreen rendering |
| <a id="sample-g-sine-scroll"></a>[`g-sine-scroll.bas`](g-sine-scroll.bas) | Hand-built bitmap font bends through a sine wave. | SPRITE$, TEST, bitmap font |
| <a id="sample-g-smoke"></a>[`g-smoke.bas`](g-smoke.bas) [★](#highlight-g-smoke) | Interactive two-dimensional fluid simulation with pressure projection, vorticity and smoothly shaded dye. | fluid simulation, MAT, bilinear interpolation, FRAME |
| <a id="sample-g-starfield"></a>[`g-starfield.bas`](g-starfield.bas) | Two thousand depth-recycled stars flow through 3D. | 3D projection, depth recycling, FRAME |
| <a id="sample-g-sunflower"></a>[`g-sunflower.bas`](g-sunflower.bas) | Animated phyllotaxis spiral with hue cycling. | phyllotaxis, custom RGB, FRAME |
| <a id="sample-g-tunnel-tquad"></a>[`g-tunnel-tquad.bas`](g-tunnel-tquad.bas) | Two boundary rings form a cylindrical tunnel with 48 native perspective-correct textured walls. | TQUAD, perspective correction, depth buffer, cylindrical geometry, texture animation |
| <a id="sample-g-tunnel"></a>[`g-tunnel.bas`](g-tunnel.bas) | BASIC texture lookup creates a block-rendered tunnel. | BLOAD, TEST, texture mapping |
| <a id="sample-g-zoomer-tquad"></a>[`g-zoomer-tquad.bas`](g-zoomer-tquad.bas) | One textured quad produces rotating zoom feedback. | TQUAD, rotation, zoom |
| <a id="sample-g-zoomer"></a>[`g-zoomer.bas`](g-zoomer.bas) [★](#highlight-g-zoomer) | Block-sampled texture mapping powers a retro zoomer. | BLOAD, TEST, block rendering |

### Games, applications, and algorithmic scenes (8)

| Sample | What it demonstrates | Techniques |
|---|---|---|
| <a id="sample-g-arkanoid"></a>[`g-arkanoid.bas`](g-arkanoid.bas) [★](#highlight-g-arkanoid) | A playable brick-breaker with stereo sound effects and sprite/color collisions. | sprite collisions, color collisions, mouse input, AUDIO, WAV |
| <a id="sample-g-chess960"></a>[`g-chess960.bas`](g-chess960.bas) [★](#highlight-g-chess960) | Generate legal Chess960 back ranks, rendered with real pieces and one-key rerolls. | DEF SUB, constrained randomization, sprites |
| <a id="sample-g-dungeon"></a>[`g-dungeon.bas`](g-dungeon.bas) [★](#highlight-g-dungeon) | Explore a textured maze with warm torch lighting and a lantern with transparent glass, find the gold key and escape through the locked gate, with original music and sound effects. | DEF SUB, DEF FN, LOCAL, array references, block IF, DDA raycasting, TRECTANGLE, TQUAD, perspective correction, vertex lighting, light map, depth testing, ALPHA, AUDIO, WAV |
| <a id="sample-g-dungeon-cpc"></a>[`g-dungeon-cpc.bas`](g-dungeon-cpc.bas) | Play the same maze with warm torch lighting, the original melody and bass arranged for three CPC voices, percussion yielding to game effects, and a three-part victory fanfare; no WAV files required. | DEF SUB, DEF FN, LOCAL, array references, block IF, SOUND, ENV, ENT, DATA, ON SQ, channel rendezvous, DDA raycasting, TQUAD, perspective correction, vertex lighting, light map, ALPHA |
| <a id="sample-g-dustline"></a>[`g-dustline.bas`](g-dustline.bas) [★](#highlight-g-dustline) | Race a banked dirt circuit with controllable drifts, persistent pixel mud, ramp jumps, a session-best ghost, and colored sector times. | DEF SUB, multiline DEF FN, LOCAL, array references, block IF, procedure error handling, BLOAD, TRECTANGLE, ALPHA, fixed-step physics, KEYDOWN, AUDIO, sequential files, spatial indexing |
| <a id="sample-g-loan"></a>[`g-loan.bas`](g-loan.bas) | Graphical loan calculator with optional amortization table. | GINPUT, DEF FN, formatted output |
| <a id="sample-g-maze"></a>[`g-maze.bas`](g-maze.bas) [★](#highlight-g-maze) | A fresh maze appears with its solution stitched through it in a dashed path. | DFS/Prim, bit masks, path reconstruction |
| <a id="sample-g-random"></a>[`g-random.bas`](g-random.bas) | Random walk runs until it reaches the border. | RND, DRAW, boundary detection |

### 3D, lighting, and texture mapping (21)

| Sample | What it demonstrates | Techniques |
|---|---|---|
| <a id="sample-g-animation"></a>[`g-animation.bas`](g-animation.bas) | A camera rotates around a mathematical surface with fixed lighting; SPACE pauses motion and C toggles the 60 FPS cap. | GTRIANGLE, procedural mesh, camera rotation, vertex lighting, FRAME |
| <a id="sample-g-animation2"></a>[`g-animation2.bas`](g-animation2.bas) [★](#highlight-g-animation2) | A rotating light shades a mathematical surface while the camera stays fixed; SPACE pauses motion and C toggles the 60 FPS cap. | GTRIANGLE, procedural mesh, moving light, vertex lighting, FRAME |
| <a id="sample-g-cloth"></a>[`g-cloth.bas`](g-cloth.bas) [★](#highlight-g-cloth) | Watch satin cloth fall and drape over a sphere in real time; SPACE pauses, R restarts the fall, and mouse dragging pulls the fabric while it runs. | DEF SUB, DEF FN, LOCAL, array references, block IF, MAT, XPBD, GTRIANGLE, fixed-step physics, state interpolation, MOUSE, FRAME |
| <a id="sample-g-cube"></a>[`g-cube.bas`](g-cube.bas) | Filled rotating cube with hidden-face removal. | 3D projection, back-face culling, FTRIANGLE |
| <a id="sample-g-cube-gouraud"></a>[`g-cube-gouraud.bas`](g-cube-gouraud.bas) | One rotating cube combines interpolated corner colors and hidden-face removal; Z toggles depth, SPACE pauses rotation, and C toggles the 60 FPS cap, with measured FPS in the HUD. | GTRIANGLE, RGB interpolation, array depth buffer |
| <a id="sample-g-cube-light"></a>[`g-cube-light.bas`](g-cube-light.bas) | A mouse-controlled diffuse light shades a rotating cube; SPACE pauses rotation while the light remains active, and C toggles the 60 FPS cap, with measured FPS in the HUD. | MOUSE, Lambert lighting, GTRIANGLE, depth buffer |
| <a id="sample-g-cube-textured-light"></a>[`g-cube-textured-light.bas`](g-cube-textured-light.bas) | A paused copper-textured cube exposes four vertex brightness values under a nearby mouse-controlled point light; F compares broad lighting, V toggles markers, SPACE rotates, and a Gouraud fin shares the depth buffer. | TTRIANGLE, TQUAD, perspective correction, RGB modulation, vertex lighting, distance attenuation, GTRIANGLE, shared depth buffer, MOUSE |
| <a id="sample-g-knot-light"></a>[`g-knot-light.bas`](g-knot-light.bas) [★](#highlight-g-knot-light) | A nearby mouse-controlled diffuse light shades a smooth tubular knot; SPACE pauses rotation while the light remains active, and C toggles the 60 FPS cap, with measured FPS in the HUD. | parametric mesh, smooth normals, MOUSE, GTRIANGLE, depth buffer |
| <a id="sample-g-shadow"></a>[`g-shadow.bas`](g-shadow.bas) | An introductory cast-shadow example with a mouse-controlled point light, an arch, and a uniform 96 x 96 floor grid; S toggles shadows and C toggles the 60 FPS cap, with measured FPS in the HUD. | GTRIANGLE, cast shadows, uniform floor mesh, MOUSE, depth buffers, FRAME |
| <a id="sample-g-shadow-adaptive"></a>[`g-shadow-adaptive.bas`](g-shadow-adaptive.bas) [★](#highlight-g-shadow-adaptive) | Move the light with the mouse and watch the arch cast shadows across the floor. | GTRIANGLE, cast shadows, shared calculations, conservative bounds, adaptive floor mesh |
| <a id="sample-g-cube2"></a>[`g-cube2.bas`](g-cube2.bas) | Two depth-sorted cubes orbit in opposite phases. | 3D projection, depth sorting, FTRIANGLE |
| <a id="sample-g-cube3"></a>[`g-cube3.bas`](g-cube3.bas) | Rotating cube fills outlined faces using flood fill. | 3D projection, DRAW, FILL |
| <a id="sample-g-cube-tquad"></a>[`g-cube-tquad.bas`](g-cube-tquad.bas) | Eight vertices defined in DATA and six native perspective-correct TQUAD faces form a spinning textured cube with depth testing. | 3D projection, DATA, perspective correction, depth buffer, TQUAD |
| <a id="sample-g-cube-transparent"></a>[`g-cube-transparent.bas`](g-cube-transparent.bas) | Six perspective-correct grille faces rotate over a four-corner Gouraud background; transparent texels reveal farther faces and background colors through a shared depth buffer. | TQUAD, color-key transparency, SPRITE$, perspective correction, GTRIANGLE, RGB interpolation, shared depth buffer |
| <a id="sample-g-demo"></a>[`g-demo.bas`](g-demo.bas) | Filled rotating cube behind a diagonal text scroll. | 3D projection, FTRIANGLE, LDIR |
| <a id="sample-g-gouraud"></a>[`g-gouraud.bas`](g-gouraud.bas) | A mathematical surface rendered with a software Z-buffer and per-vertex lighting. | Z-buffer, barycentric rasterization, vertex lighting |
| <a id="sample-g-lambert"></a>[`g-lambert.bas`](g-lambert.bas) | Painter-sorted surface uses flat Lambert lighting. | painter's algorithm, Lambert shading, quicksort |
| <a id="sample-g-origin"></a>[`g-origin.bas`](g-origin.bas) | Rotating cube moves inside a bouncing viewport. | ORIGIN, 3D projection, viewport animation |
| <a id="sample-g-raytracer"></a>[`g-raytracer.bas`](g-raytracer.bas) [★](#highlight-g-raytracer) | A 640×480 glass-and-mirrors scene ray-traced entirely in BASIC. | ray tracing, Fresnel, reflection and refraction |
| <a id="sample-g-sphere"></a>[`g-sphere.bas`](g-sphere.bas) | Parametric line sweep sketches a colored sphere. | parametric plotting, SCALE, DRAW |
| <a id="sample-g-voxel"></a>[`g-voxel.bas`](g-voxel.bas) [★](#highlight-g-voxel) | Fly over a procedural landscape with filtered lighting, cached fog colors and adjustable viewing distance. | voxel terrain, procedural generation, lighting, fog, FRAME |

### Fractals, curves, and procedural geometry (15)

| Sample | What it demonstrates | Techniques |
|---|---|---|
| <a id="sample-g-chords"></a>[`g-chords.bas`](g-chords.bas) | Complete chord graph drawn around a circle. | polar coordinates, DRAW, FRAME |
| <a id="sample-g-fdragon"></a>[`g-fdragon.bas`](g-fdragon.bas) | Dragon curve drawn with simulated recursive calls. | simulated recursion, DRAWR, arrays |
| <a id="sample-g-fhilbert"></a>[`g-fhilbert.bas`](g-fhilbert.bas) | Hilbert curve generated from an expanded L-system. | L-system, string rewriting, DRAWR |
| <a id="sample-g-flevy"></a>[`g-flevy.bas`](g-flevy.bas) | Lévy curve uses an explicit recursion state machine. | recursion state machine, arrays, DRAW |
| <a id="sample-g-flevy2"></a>[`g-flevy2.bas`](g-flevy2.bas) | Iterative L-system draws a Lévy C curve. | L-system, string expansion, DRAWR |
| <a id="sample-g-fmandelbrot"></a>[`g-fmandelbrot.bas`](g-fmandelbrot.bas) [★](#highlight-g-fmandelbrot) | Click into the Mandelbrot set and dive deeper with every redraw. | complex iteration, mouse zoom, SCALE |
| <a id="sample-g-fsierpinski"></a>[`g-fsierpinski.bas`](g-fsierpinski.bas) | Recursive Sierpiński triangle drawn through shrinking steps. | recursion, trigonometry, DRAW |
| <a id="sample-g-fsnow"></a>[`g-fsnow.bas`](g-fsnow.bas) | Koch snowflake generated by iterative L-system expansion. | L-system, string expansion, DRAWR |
| <a id="sample-g-ftree"></a>[`g-ftree.bas`](g-ftree.bas) | Monochrome binary tree simulates recursion with arrays. | simulated recursion, arrays, FRAME |
| <a id="sample-g-ftree2"></a>[`g-ftree2.bas`](g-ftree2.bas) | Organic branching tree adds depth-based width and color. | simulated recursion, line width, color gradient |
| <a id="sample-g-ftree3"></a>[`g-ftree3.bas`](g-ftree3.bas) | Three-stage color gradient enriches the recursive tree. | simulated recursion, multi-stage color, line width |
| <a id="sample-g-ftree4"></a>[`g-ftree4.bas`](g-ftree4.bas) [★](#highlight-g-ftree4) | Animated swaying tree redraws recursive branches each frame. | simulated recursion, EVERY, offscreen rendering |
| <a id="sample-g-parametric"></a>[`g-parametric.bas`](g-parametric.bas) | Rainbow multi-frequency curve uses custom color functions. | DEF FN, parametric plotting, RGB |
| <a id="sample-g-parametric2"></a>[`g-parametric2.bas`](g-parametric2.bas) | Rainbow Lissajous curve traces a three-by-four ratio. | DEF FN, Lissajous curve, RGB |
| <a id="sample-g-parametric3"></a>[`g-parametric3.bas`](g-parametric3.bas) | Dense rainbow Lissajous curve uses adjacent frequencies. | DEF FN, Lissajous curve, RGB |

### Plotting, charts, and mathematical visualization (21)

| Sample | What it demonstrates | Techniques |
|---|---|---|
| <a id="sample-g-axis-labels"></a>[`g-axis-labels.bas`](g-axis-labels.bas) | Demonstrates automatic tick spacing, dense explicit steps, fractional crossings, and label orientation. | XAXIS and YAXIS, CROSSAT, adaptive labels |
| <a id="sample-g-axis"></a>[`g-axis.bas`](g-axis.bas) | Minimal shifted-axis example using SCALE and CROSSAT. | SCALE, CROSSAT, XAXIS and YAXIS |
| <a id="sample-g-bifurcation"></a>[`g-bifurcation.bas`](g-bifurcation.bas) [★](#highlight-g-bifurcation) | Explore chaos by clicking into a rainbow logistic-map bifurcation diagram. | logistic map, Lyapunov exponent, mouse zoom |
| <a id="sample-g-function"></a>[`g-function.bas`](g-function.bas) | Plots sine from a string expression with axes. | GRAPH, string expression, axes |
| <a id="sample-g-function2"></a>[`g-function2.bas`](g-function2.bas) | Plots tangent directly across multiple discontinuities. | GRAPH, discontinuities, SCALE |
| <a id="sample-g-function2b"></a>[`g-function2b.bas`](g-function2b.bas) | Manually plots tangent while skipping discontinuity jumps. | DEF FN, error handling, discontinuity filtering |
| <a id="sample-g-function3"></a>[`g-function3.bas`](g-function3.bas) | Plots one reciprocal branch on a negative domain. | GRAPH, SCALE, axes |
| <a id="sample-g-function4"></a>[`g-function4.bas`](g-function4.bas) | Plots a complex nested expression with highlighted subrange. | GRAPH, GRAPHRANGE, MASK |
| <a id="sample-g-function5"></a>[`g-function5.bas`](g-function5.bas) | Plots sinc with sampled stems and labeled axes. | DEF FN, GRAPH, sample stems |
| <a id="sample-g-function6"></a>[`g-function6.bas`](g-function6.bas) | Plots a composite trigonometric-exponential string expression. | GRAPH, string expression, SCALE |
| <a id="sample-g-function7"></a>[`g-function7.bas`](g-function7.bas) | Plots an enormous polynomial with exponential tick labels. | DEF FN, exponential labels, axes |
| <a id="sample-g-origin-scale"></a>[`g-origin-scale.bas`](g-origin-scale.bas) | Four independent mathematical canvases share one screen: plots, data, axes and fractals. | DEF SUB, ORIGIN and SCALE, GRAPHRANGE |
| <a id="sample-g-regression"></a>[`g-regression.bas`](g-regression.bas) | Fits and plots a linear regression from DATA. | least squares, DATA, GRAPH |
| <a id="sample-g-scale"></a>[`g-scale.bas`](g-scale.bas) | Demonstrates axis-label placement on a data scale. | SCALE, CROSSAT, axis labels |
| <a id="sample-g-scale2"></a>[`g-scale2.bas`](g-scale2.bas) | Draws a labeled cardioid in polar coordinates. | polar coordinates, SCALE, DRAW |
| <a id="sample-g-scale3"></a>[`g-scale3.bas`](g-scale3.bas) | Charts historical Olympic freestyle times by sex. | DATA, SCALE, custom markers |
| <a id="sample-g-scale4"></a>[`g-scale4.bas`](g-scale4.bas) | Repeats zero-tick axes along a diagonal grid. | CROSSAT, XAXIS, YAXIS |
| <a id="sample-g-scale5"></a>[`g-scale5.bas`](g-scale5.bas) | Clips a reciprocal graph to one custom range. | GRAPHRANGE, GRAPH, SCALE |
| <a id="sample-g-scale6"></a>[`g-scale6.bas`](g-scale6.bas) | Overlays masked reciprocal plots across two ranges. | GRAPHRANGE, MASK, GRAPH |
| <a id="sample-g-scale7"></a>[`g-scale7.bas`](g-scale7.bas) | Shows aspect-ratio effects on two nominal circles. | SCALE, CIRCLE, aspect ratio |
| <a id="sample-g-scale8"></a>[`g-scale8.bas`](g-scale8.bas) | Builds a DATA-driven bar chart with scaled axes. | DATA, RECTANGLE, scaled axes |

### Drawing, color, and coordinate primitives (11)

| Sample | What it demonstrates | Techniques |
|---|---|---|
| <a id="sample-g-colors"></a>[`g-colors.bas`](g-colors.bas) | Documents supported color syntaxes with labeled swatches. | INK and PAPER, RGB, named colors |
| <a id="sample-g-demo2"></a>[`g-demo2.bas`](g-demo2.bas) | Tiny random circle-and-fill drawing test. | CIRCLE, FILL, RND |
| <a id="sample-g-demo3"></a>[`g-demo3.bas`](g-demo3.bas) | Random filled circles and rectangles benchmark primitives. | FCIRCLE, FRECTANGLE, FRAME |
| <a id="sample-g-demo4"></a>[`g-demo4.bas`](g-demo4.bas) | Random filled triangles benchmark rasterization. | FTRIANGLE, RND, FRAME |
| <a id="sample-g-line"></a>[`g-line.bas`](g-line.bas) | Bouncing rotating line exercises relative origin changes. | ORIGIN, DRAW, animation |
| <a id="sample-g-mask"></a>[`g-mask.bas`](g-mask.bas) | Four line patterns demonstrate binary drawing masks. | MASK, DRAW, binary patterns |
| <a id="sample-g-origin2"></a>[`g-origin2.bas`](g-origin2.bas) | Random shapes are clipped to a custom viewport. | ORIGIN, clipping, filled primitives |
| <a id="sample-g-palette"></a>[`g-palette.bas`](g-palette.bas) | Displays all 32 indexed colors in a grid. | FILL, LOCATE, indexed colors |
| <a id="sample-g-relative"></a>[`g-relative.bas`](g-relative.bas) | Short path demonstrates relative moves and draws. | DRAWR, MOVER, named colors |
| <a id="sample-g-texture-transparent"></a>[`g-texture-transparent.bas`](g-texture-transparent.bas) | Compare opaque and transparent rows of 2D rectangles, triangles, and quads over a checkerboard, including automatic and repeating UVs; ESC exits. | TRECTANGLE, TTRIANGLE, TQUAD, color-key transparency, SPRITE$, wrapped UVs |
| <a id="sample-g-width"></a>[`g-width.bas`](g-width.bas) | Compares pen widths on lines and overlapping points. | PENWIDTH, DRAW, PLOT |

### Text and typography (13)

| Sample | What it demonstrates | Techniques |
|---|---|---|
| <a id="sample-g-banner"></a>[`g-banner.bas`](g-banner.bas) | Rebuilds AVL BASIC as a large character banner. | LABEL, TEST, GPRINT |
| <a id="sample-g-chartest"></a>[`g-chartest.bas`](g-chartest.bas) | Exercises accented glyphs, symbols, fonts, and transparency. | Unicode text, font modes, transparency |
| <a id="sample-g-chartest2"></a>[`g-chartest2.bas`](g-chartest2.bas) | Randomly places Spanish labels as a text stress test. | LABEL, RND, FRAME |
| <a id="sample-g-ldir"></a>[`g-ldir.bas`](g-ldir.bas) | Places sample labels at many text directions. | LDIR, LABEL, GPRINT |
| <a id="sample-g-ldir2"></a>[`g-ldir2.bas`](g-ldir2.bas) | Arranges a copyright string around a circle. | LDIR, trigonometry, LABEL |
| <a id="sample-g-ldir3"></a>[`g-ldir3.bas`](g-ldir3.bas) | Animates one rotating ring of directional text. | LDIR, offscreen rendering, FRAME |
| <a id="sample-g-ldir4"></a>[`g-ldir4.bas`](g-ldir4.bas) | Animates two concentric rings of directional text. | LDIR, offscreen rendering, FRAME |
| <a id="sample-g-ldirt"></a>[`g-ldirt.bas`](g-ldirt.bas) | Times repeated rendering of one rotating text ring. | LDIR, timing, FRAME |
| <a id="sample-g-ldirt2"></a>[`g-ldirt2.bas`](g-ldirt2.bas) | Times repeated rendering of two rotating text rings. | LDIR, timing, FRAME |
| <a id="sample-g-locate"></a>[`g-locate.bas`](g-locate.bas) | Mixes font sizes, cursor positions, and labels. | LOCATE, font modes, LABEL |
| <a id="sample-g-strings"></a>[`g-strings.bas`](g-strings.bas) | Compares colored opaque and transparent text output. | INK and PAPER, font modes, LABEL |
| <a id="sample-g-text"></a>[`g-text.bas`](g-text.bas) | Scrolls numeric text by changing its substring offset. | GPRINT, MID$, font modes |
| <a id="sample-g-usflag"></a>[`g-usflag.bas`](g-usflag.bas) | Draws a text-cell United States flag. | LOCATE, GPRINT, PAPER |

### Sprites, images, and frame animation (10)

| Sample | What it demonstrates | Techniques |
|---|---|---|
| <a id="sample-g-balls"></a>[`g-balls.bas`](g-balls.bas) [★](#highlight-g-balls) | Fifty numbered sprites bounce and collide without full clears. | sprite collisions, dirty redraw, COLMODE |
| <a id="sample-g-png-animation"></a>[`g-png-animation.bas`](g-png-animation.bas) | A short anime dance loops from preloaded PNG frames. | BLOAD, string arrays, SCREEN, FRAME |
| <a id="sample-g-sprite"></a>[`g-sprite.bas`](g-sprite.bas) | Captures and redraws one sprite with transparency variants. | SPRITE$, SPRITE, transparency |
| <a id="sample-g-sprite-alpha"></a>[`g-sprite-alpha.bas`](g-sprite-alpha.bas) | A large, multicolored anime fairy moves and fades from 0% to 100% opacity over an anime image; translucent panels use the same ALPHA clause. | SPRITE MOVE, ALPHA, color-key transparency, BLOAD, frame restoration |
| <a id="sample-g-sprite-layers"></a>[`g-sprite-layers.bas`](g-sprite-layers.bas) | Two aligned anime fairy sprites move together: half-transparent wings behind a fully opaque body. | SPRITE$, SPRITE MOVE, ALPHA, sprite layers, color-key transparency |
| <a id="sample-g-sprite2"></a>[`g-sprite2.bas`](g-sprite2.bas) | Repeats sprite transparency inside a scaled viewport. | SPRITE$, ORIGIN, transparency |
| <a id="sample-g-sprite3"></a>[`g-sprite3.bas`](g-sprite3.bas) | Benchmarks many randomly placed transparent sprites. | SPRITE$, RND, FRAME |
| <a id="sample-g-sprite4"></a>[`g-sprite4.bas`](g-sprite4.bas) | Drags a sprite while restoring its captured background. | mouse events, background capture, SPRITE |
| <a id="sample-g-sprite5"></a>[`g-sprite5.bas`](g-sprite5.bas) | Demonstrates both color and sprite collision modes. | COLMODE, HITTEST, HITID |
| <a id="sample-g-swap"></a>[`g-swap.bas`](g-swap.bas) | Benchmarks swapping two full-screen graphics buffers. | BLOAD, SCREEN, SWAP |

### Input, events, and timing (6)

| Sample | What it demonstrates | Techniques |
|---|---|---|
| <a id="sample-g-inkey"></a>[`g-inkey.bas`](g-inkey.bas) | Displays graphical key input and numeric codes. | INKEY$, ASC, graphics console |
| <a id="sample-g-input"></a>[`g-input.bas`](g-input.bas) | Collects name and age through graphical input fields. | GINPUT, GPRINT, PAUSE |
| <a id="sample-g-mouse"></a>[`g-mouse.bas`](g-mouse.bas) | Draws rectangles from mouse press-and-release events. | ON MOUSE, event callbacks, FRECTANGLE |
| <a id="sample-g-mouse2"></a>[`g-mouse2.bas`](g-mouse2.bas) | Freehand drawing follows mouse drag events. | LEFTDRAG, MASK, DRAW |
| <a id="sample-inkey"></a>[`inkey.bas`](inkey.bas) | Displays console key input and numeric codes. | INKEY$, ASC, console input |
| <a id="sample-interrupts"></a>[`interrupts.bas`](interrupts.bas) | Scheduled callbacks race to guess a random letter. | EVERY, AFTER, callbacks |

### Sound and music (4)

| Sample | What it demonstrates | Techniques |
|---|---|---|
| <a id="sample-s-melody"></a>[`s-melody.bas`](s-melody.bas) | Releases a held three-voice chord, then plays a melody with volume and tone envelopes. | SOUND, ENV, ENT, RELEASE, SQ |
| <a id="sample-s-queue"></a>[`s-queue.bas`](s-queue.bas) | Rearms a one-shot queue event to supply notes while the main loop keeps running. | ON SQ, SOUND, asynchronous playback |
| <a id="sample-s-cpc-duet"></a>[`s-cpc-duet.bas`](s-cpc-duet.bas) | Plays a two-part score with queue callbacks, channel rendezvous, and fractional tone periods. | ON SQ, SOUND, ENV, ENT, rendezvous |
| <a id="sample-s-audio"></a>[`s-audio.bas`](s-audio.bas) | Loops an included WAV with pan and rate transitions, pause, resume, and a volume fade. | AUDIO, AUDIOSTATE, AUDIOPOS, WAV |

### Sequential data files (3)

Each example creates or replaces its own named demonstration file beside the
program, then reads it back.

| Sample | What it demonstrates | Techniques |
|---|---|---|
| <a id="sample-f-scores"></a>[`f-scores.bas`](f-scores.bas) | Saves scores, appends one player, and reads every record. | OPEN, WRITE #, INPUT #, EOF, CLOSE |
| <a id="sample-f-text"></a>[`f-text.bas`](f-text.bas) | Writes a formatted report and appends to an unfinished line. | PRINT #, USING, APPEND, LINE INPUT # |
| <a id="sample-f-records"></a>[`f-records.bas`](f-records.bas) | Recovers quotes, commas, line breaks, empty strings, and numeric precision. | CSV quoting, CHR$, WRITE #, INPUT # |

### Console algorithms and language features (13)

| Sample | What it demonstrates | Techniques |
|---|---|---|
| <a id="sample-g-subsample"></a>[`g-subsample.bas`](g-subsample.bas) | Demonstrates DEF SUB locals, shared names, and scope failure. | DEF SUB, LOCAL, scope |
| <a id="sample-iif"></a>[`iif.bas`](iif.bas) | Select numeric or string results with nested IIF expressions while safely skipping unused divisions by zero. | IIF, conditional evaluation, strings, nested expressions |
| <a id="sample-loan"></a>[`loan.bas`](loan.bas) | Console loan calculator with first-year amortization table. | INPUT, DEF FN, formatted output |
| <a id="sample-matrix"></a>[`matrix.bas`](matrix.bas) | Inverts, transposes, multiplies, and prints a matrix. | MAT INV, MAT TRN, DET |
| <a id="sample-matrix-expressions"></a>[`matrix-expressions.bas`](matrix-expressions.bas) | Combine matrix products, scalar operations, transposes, inverses, and statistics using BASIC expression precedence. | MAT, compound expressions, TRN, INV, SUM |
| <a id="sample-matrix-subarrays"></a>[`matrix-subarrays.bas`](matrix-subarrays.bas) | Copy matrix blocks, rows, and columns, then demonstrate overlapping and reversed vector ranges. | MAT, subarrays, MAT BASE, overlapping copies |
| <a id="sample-nqueens"></a>[`nqueens.bas`](nqueens.bas) | Backtracking solves and prints a sixteen-queen board. | backtracking, arrays, formatted output |
| <a id="sample-nr-factorial"></a>[`nr-factorial.bas`](nr-factorial.bas) | Computes 100 factorial using nine-digit integer blocks. | arbitrary precision, arrays, PRINT USING |
| <a id="sample-palette"></a>[`palette.bas`](palette.bas) | Lists named colors and their packed RGB values. | RGB, HEX$, DATA |
| <a id="sample-pimachin"></a>[`pimachin.bas`](pimachin.bas) | GOSUB-based Machin algorithm computes 1,000 pi digits. | arbitrary precision, GOSUB, Machin formula |
| <a id="sample-pimachin-mat"></a>[`pimachin-mat.bas`](pimachin-mat.bas) | Compute 1,000 pi digits with vector addition and subtraction, retaining BASIC loops for carries and borrows. | MAT, vector arithmetic, arbitrary precision, Machin formula |
| <a id="sample-pimachin-modern"></a>[`pimachin-modern.bas`](pimachin-modern.bas) | Compute 1,000 digits of π with block arithmetic and structured, modern BASIC. | DEF SUB, LOCAL, arbitrary precision |
| <a id="sample-powermul"></a>[`powermul.bas`](powermul.bas) | Computes arbitrary-precision integer powers by block multiplication. | DEF SUB, block multiplication, PRINT USING |

★ Featured in the 20-example gallery.

## Run from a shell

From the repository or package root:

```console
avl-basic samples/g-old-school.bas
```

On Windows, use `avl-basic.exe` and backslashes if preferred.
