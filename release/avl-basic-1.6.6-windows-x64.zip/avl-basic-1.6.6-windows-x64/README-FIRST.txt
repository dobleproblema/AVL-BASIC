AVL BASIC 1.6.6 for Windows

Quick start
-----------

Double-click avl-basic.exe, or open a terminal in this folder and run:

    avl-basic.exe

Run a bundled example:

    avl-basic.exe samples\g-old-school.bas

Inside AVL BASIC:

    HELP RIGHT$

HELP topic gives a compact syntax and parameter reminder. The interpreter itself
is fully self-contained. The samples directory contains optional material
distributed with this package for exploration; its visual gallery and annotated
catalog are in samples\README.md.

Open README.html in your browser for the project overview and image gallery.
Its images are embedded, so the document works offline.

Open MANUAL.html in your browser for the English manual or MANUAL.es.html
for Spanish. Both manuals are beside the executable and work offline.
To try a complete example, enter NEW and CD "/", paste it, then enter RUN.
Start the interpreter in this package folder so samples/assets paths resolve.

This package uses the native Rust runtime. You do not need to install Rust or
Cargo to use it.

Included files
--------------

- avl-basic.exe: native Windows interpreter
- README.html: offline project overview with embedded images
- samples/: optional collection of BASIC programs, gallery, catalog, and assets
- MANUAL.html: offline English manual with navigation, search and copyable examples
- MANUAL.es.html: offline Spanish manual with the same features
- COPYING: MIT project license
- LICENSES: third-party licenses and copyright notices
