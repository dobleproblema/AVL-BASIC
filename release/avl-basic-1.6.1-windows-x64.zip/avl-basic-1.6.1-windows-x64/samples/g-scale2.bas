10 SCREEN : CLG : SMALLFONT
15 SCALE -3,1,-2,2,20
20 XAXIS 0.5,-3,1,-1 'A negative side draws ticks without labels
25 YAXIS 0.5,-2,2,-1
30 RAD
35 MOVE 0,0 : PENWIDTH 2 : INK 2
40 FOR t=0 TO 2*PI STEP 0.01
45 r=1-COS(t)
50 DRAW r*COS(t),r*SIN(t)
55 NEXT t
60 INK 1 : MOVE -2.75,-1.5
65 LABEL "r=1-cosØ"
70 END
