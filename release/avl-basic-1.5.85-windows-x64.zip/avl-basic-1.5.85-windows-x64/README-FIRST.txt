AVL BASIC 1.5.85 for Windows

Quick start
-----------

Double-click avl-basic.exe, or open a terminal in this folder and run:

    avl-basic.exe

Run a bundled example:

    avl-basic.exe samples\g-cube2.bas

Inside AVL BASIC:

    CD "samples"
    FILES "*.bas"
    RUN "g-cube2.bas"

This package uses the native Rust runtime. You do not need to install Rust or
Cargo to use it.

Included files
--------------

- avl-basic.exe: native Windows interpreter
- samples/: bundled BASIC programs and assets
- MANUAL.txt: English manual
- MANUAL.es.txt: Spanish manual
- COPYING: GPLv3-or-later license
