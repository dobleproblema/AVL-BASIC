AVL BASIC 1.5.94 for Windows

Quick start
-----------

Double-click avl-basic.exe, or open a terminal in this folder and run:

    avl-basic.exe

Run a bundled example:

    avl-basic.exe samples\g-old-school.bas

Inside AVL BASIC:

    HELP RIGHT$

HELP topic gives a compact syntax and parameter reminder. The interpreter itself
is fully self-contained. The samples directory contains optional material
distributed with this package for exploration; its visual gallery and annotated
catalog are in samples\README.md.

This package uses the native Rust runtime. You do not need to install Rust or
Cargo to use it.

Included files
--------------

- avl-basic.exe: native Windows interpreter
- samples/: optional collection of BASIC programs, gallery, catalog, and assets
- MANUAL.txt: English manual
- MANUAL.es.txt: Spanish manual
- COPYING: GPLv3-or-later license
