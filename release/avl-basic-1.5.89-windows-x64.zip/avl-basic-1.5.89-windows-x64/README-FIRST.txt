AVL BASIC 1.5.89 for Windows

Quick start
-----------

Double-click avl-basic.exe, or open a terminal in this folder and run:

    avl-basic.exe

Run a bundled example:

    avl-basic.exe samples\g-old-school.bas

Inside AVL BASIC:

    TOUR
    SAMPLES
    RUN "/samples/g-old-school.bas"

TOUR presents 20 highlights with descriptions and ready-to-copy RUN commands.
SAMPLES lists all 115 bundled programs by category. The complete visual gallery
and annotated catalog are in samples\README.md.

This package uses the native Rust runtime. You do not need to install Rust or
Cargo to use it.

Included files
--------------

- avl-basic.exe: native Windows interpreter
- samples/: 115 BASIC programs, visual gallery, catalog, and assets
- MANUAL.txt: English manual
- MANUAL.es.txt: Spanish manual
- COPYING: GPLv3-or-later license
