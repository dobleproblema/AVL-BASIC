100 MODE 800
110 B=40 'Border discarded at each end so the labels fit
120 SCREEN : CLG
130 SCALE -10,0,-2,0,B
140 XAXIS 1,,,1
150 YAXIS 0.5,,,1
160 PENWIDTH 2 : INK 2
170 GRAPH 1/X
180 END
