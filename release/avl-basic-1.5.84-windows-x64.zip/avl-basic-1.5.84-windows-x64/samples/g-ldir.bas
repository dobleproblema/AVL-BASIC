10 CLG
20 BIGFONT
30 LDIR 0
40 MOVE WIDTH\2,HEIGHT\2
50 GPRINT "hello ";
55 LABEL "hello"
60 LDIR 90
70 GPRINT "hello ";
75 LABEL "hello "
80 LDIR 0
95 LABEL "hello "
100 LDIR -90
115 LABEL "hello"
125 LABEL "hello "
130 LDIR 180
140 LABEL "hello"
150 LDIR 270
160 LABEL "hello  "
170 LDIR 135
180 LABEL " hello"
190 LABEL "hello"
200 LABEL "hello "
210 LDIR 45
220 LABEL "hello  "
230 LDIR -90
240 LABEL " hello"

